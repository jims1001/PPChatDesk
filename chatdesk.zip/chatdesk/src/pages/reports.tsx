export default function Reports() {
    return <div className="text-gray-600">Reports 页面（占位）</div>
}