
import EmptyState from '@/components/emptyState'

export default function InboxMentions() {
    return <EmptyState text="@ 提及会显示在这里。" />
}