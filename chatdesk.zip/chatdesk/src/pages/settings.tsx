export default function Settings() {
    return <div className="text-gray-600">Settings 页面（占位）</div>
}