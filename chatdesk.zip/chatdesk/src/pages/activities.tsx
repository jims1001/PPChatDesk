export default function Activities() {
    return <div className="text-gray-600">Activities 页面（占位）</div>
}