export default function Help() {
    return <div className="text-gray-600">Help 页面（占位）</div>
}