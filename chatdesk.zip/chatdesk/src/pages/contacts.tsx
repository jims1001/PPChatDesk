export default function Contacts() {
    return <div className="text-gray-600">Contacts 页面（占位）</div>
}